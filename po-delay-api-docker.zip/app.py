from flask import Flask, request, jsonify
import joblib
import numpy as np

app = Flask(__name__)

# Load model and encoder
model = joblib.load('po_delay_model.pkl')
vendor_encoder = joblib.load('vendor_encoder.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        vendor = data['vendor']
        leadtime = data['leadtime']
        vendor_encoded = vendor_encoder.transform([vendor])
        X_new = np.array([[vendor_encoded[0], leadtime]])
        predicted_delay = model.predict(X_new)[0]
        return jsonify({'predicted_delay': round(predicted_delay, 2)})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
